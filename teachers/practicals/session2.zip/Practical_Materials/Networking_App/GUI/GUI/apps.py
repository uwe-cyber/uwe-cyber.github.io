from django.apps import AppConfig


class GUIConfig(AppConfig):
    name = 'GUI'
